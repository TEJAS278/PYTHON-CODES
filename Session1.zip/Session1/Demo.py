a=20.25  #Declaration of variable a
print(a)

str="ghhghgthth"

str="""gfbhd
hh
ghg
ghd
"""

num=27
print(num/5)
print(num//5)
print(5**3)
print(num>20 and num<30)
print(('Hello'+'Karan' )*3)
str='python'

print(str[2])
print(str.capitalize())
str1="Java"
print(str1.count('a',2,len(str1)))
print(str1.find('a',2,len(str1)))


if(num>42):
    print("In the if block")
    print(num," is greater than 42")
else:
    print(num," is less than 42")

v='e'

if(v=='a'):
    print("it is a vowel ")
elif(v=='e'):
    print("it is a vowel ")
else:
    print("Its not a vowel")
a=1
print("=========while loop======")
while(a<11):
    print(a)
    a=a+1
else:
    print("While never executed")
print("=========for loop with range()======")
for x in range(1,10):
    print(x)

print("=========for loop with string======")
count=0
for s in str1:
    print(s)
    if(s=='a'):
        count=count+1

print("a is present in str1 ",count," times")




print("=========for loop with range() -increment value ======")
for x in range(1,10,2):
    
    if(x==5):
        continue
    print(x)

print("=========Accepting the input ======")
print("\n Enter the value for n : ")
n=input()

print("\n n = ",n)

print("=========Accepting the input by passing a msg ======")
n1=input("\n Enter the value for n1 : ")
print("\n n = ",n1)
n1=int(n1)
print(n1*2)


print("=========Accepting the input by passing a msg and converting to a type ======")
n2=int(input("\n Enter the value for n2 : "))
print("\n n = ",n2)
print(n2**2)































